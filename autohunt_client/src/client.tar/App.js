import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import { AppContainer, Footer } from "./styles/AppStyles";
import Header from "./components/Header";
import ScanForm from "./components/ScanForm";
import ScanResults from "./components/ScanResults";

const App = () => {
  const [results, setResults] = React.useState([]);

  const handleScanSubmit = (event) => {
    event.preventDefault();
    // Mock data for results
    setResults([
      { target: "192.168.1.1", status: "Complete", details: "No issues found." },
      { target: "example.com", status: "Complete", details: "Vulnerabilities detected." },
    ]);
  };

  return (
    <AppContainer>
      <Header />
      <Container className="py-5">
        <Row className="justify-content-center mb-5">
          <Col md={8} lg={6}>
            <h1 className="text-center mb-4">Initiate a Security Scan</h1>
            <ScanForm onSubmit={handleScanSubmit} />
          </Col>
        </Row>
        <Row className="justify-content-center">
          <Col md={10}>
            <h2 className="text-center mb-4">Scan Results</h2>
            <ScanResults results={results} />
          </Col>
        </Row>
      </Container>
      <Footer>
        <p>&copy; {new Date().getFullYear()} AutoHunt | Empowering Security</p>
      </Footer>
    </AppContainer>
  );
};

export default App;
